<?php
/**
 *  UABB Button Module front-end file
 *
 *  @package UABB Button Module
 */

echo $module->render_button(); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
