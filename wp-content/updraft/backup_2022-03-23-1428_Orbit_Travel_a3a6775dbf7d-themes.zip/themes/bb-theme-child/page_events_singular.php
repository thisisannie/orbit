<?php
/*
Template Name: Events Singular
Template Post Type: page, post
*/
//Substitute your own page ID in the following line
FLThemeBuilderLayoutRenderer::render_all( 1118 );