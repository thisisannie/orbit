<div class="fl-page-bar">
	<div class="fl-page-bar-container <?php FLLayout::container_class(); ?>">
		<div class="fl-page-bar-row <?php FLLayout::row_class(); ?>">
			<?php FLTheme::top_bar_col1(); ?>
			<?php FLTheme::top_bar_col2(); ?>
		</div>
	</div>
</div><!-- .fl-page-bar -->
