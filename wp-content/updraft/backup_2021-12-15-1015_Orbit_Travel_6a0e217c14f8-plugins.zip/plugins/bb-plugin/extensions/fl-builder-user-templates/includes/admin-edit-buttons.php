<div class="fl-builder-buttons">
	<a href="<?php echo FLBuilderModel::get_edit_url(); ?>" class="fl-launch-builder button button-primary button-large"><?php echo $edit; ?></a>
	<a href="<?php echo get_permalink(); ?>" class="fl-view-template button button-large"><?php echo $view; ?></a>
</div>
