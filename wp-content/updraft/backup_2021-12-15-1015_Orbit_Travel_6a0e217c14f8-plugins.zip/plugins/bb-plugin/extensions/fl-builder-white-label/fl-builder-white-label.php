<?php

// Defines
define( 'FL_BUILDER_WHITE_LABEL_DIR', FL_BUILDER_DIR . 'extensions/fl-builder-white-label/' );
define( 'FL_BUILDER_WHITE_LABEL_URL', FL_BUILDER_URL . 'extensions/fl-builder-white-label/' );

// Classes
require_once FL_BUILDER_WHITE_LABEL_DIR . 'classes/class-fl-builder-white-label.php';
