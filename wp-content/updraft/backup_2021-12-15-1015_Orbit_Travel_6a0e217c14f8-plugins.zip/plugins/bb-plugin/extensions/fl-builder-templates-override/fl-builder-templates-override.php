<?php

// Defines
define( 'FL_BUILDER_TEMPLATES_OVERRIDE_DIR', FL_BUILDER_DIR . 'extensions/fl-builder-templates-override/' );
define( 'FL_BUILDER_TEMPLATES_OVERRIDE_URL', FL_BUILDER_URL . 'extensions/fl-builder-templates-override/' );

// Classes
require_once FL_BUILDER_TEMPLATES_OVERRIDE_DIR . 'classes/class-fl-builder-templates-override.php';
