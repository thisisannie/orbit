<div class="fl-page-footer-widgets">
	<div class="fl-page-footer-widgets-container container">
		<div class="fl-page-footer-widgets-row row">
		<?php FLTheme::display_footer_widgets(); ?>
		</div>
	</div>
</div><!-- .fl-page-footer-widgets -->
