(function($) {

	$(function() {

		new FLBuilderPricingTable({
			id: '<?php echo $id; ?>',
		});

	});

})(jQuery);
