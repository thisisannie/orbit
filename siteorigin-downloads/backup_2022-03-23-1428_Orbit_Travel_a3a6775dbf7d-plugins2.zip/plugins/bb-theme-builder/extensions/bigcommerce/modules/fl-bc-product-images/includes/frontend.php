<?php
echo FLPageDataBigCommerce::get_product_images_component();
