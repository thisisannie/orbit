<?php
echo FLPageDataBigCommerce::get_product_description();
