<?php
echo FLPageDataBigCommerce::get_related_products();
