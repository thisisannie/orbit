<?php
echo FLPageDataBigCommerce::get_product_specs();
