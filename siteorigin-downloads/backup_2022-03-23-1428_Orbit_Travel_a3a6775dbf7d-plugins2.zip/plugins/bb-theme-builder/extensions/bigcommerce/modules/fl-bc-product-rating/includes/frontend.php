<?php
echo FLPageDataBigCommerce::get_product_rating_stars_html();
