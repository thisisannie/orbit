<?php
return array(
	'star_rating'  => FLThemeBuilderBigCommerceSettings::get( 'ratings/star-rating' ),
	'reviews_link' => FLThemeBuilderBigCommerceSettings::get( 'ratings/reviews-link' ),
);
