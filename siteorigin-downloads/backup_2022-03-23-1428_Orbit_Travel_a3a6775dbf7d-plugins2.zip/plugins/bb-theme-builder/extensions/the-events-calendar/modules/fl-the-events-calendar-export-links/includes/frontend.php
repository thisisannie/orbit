<?php

tribe( 'tec.iCal' )->single_event_links();
