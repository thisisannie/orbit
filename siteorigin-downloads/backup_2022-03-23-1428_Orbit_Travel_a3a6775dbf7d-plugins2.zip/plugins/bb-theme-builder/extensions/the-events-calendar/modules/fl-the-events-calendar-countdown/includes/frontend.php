[tribe_event_countdown id="<?php the_ID(); ?>"<?php echo ( $settings->show_seconds ) ? ' show_seconds="yes"' : ''; ?>]
