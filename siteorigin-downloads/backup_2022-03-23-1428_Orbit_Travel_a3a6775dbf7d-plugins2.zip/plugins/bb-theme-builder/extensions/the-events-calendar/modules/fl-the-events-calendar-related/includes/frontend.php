<?php
if ( function_exists( 'tribe_single_related_events' ) ) {
	tribe_single_related_events();
}
