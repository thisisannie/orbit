<div class="fl-author-bio-thumb">
	<?php echo do_shortcode( '[wpbb post:author_profile_picture link="0" size="' . $settings->image_size . '"]' ); ?>
</div>
<div class="fl-author-bio-content">
	<h3 class="fl-author-bio-name"><?php echo do_shortcode( '[wpbb post:author_name link="no"]' ); ?></h3>
	<div class="fl-author-bio-text"><?php echo do_shortcode( '[wpbb post:author_bio]' ); ?></div>
</div>
