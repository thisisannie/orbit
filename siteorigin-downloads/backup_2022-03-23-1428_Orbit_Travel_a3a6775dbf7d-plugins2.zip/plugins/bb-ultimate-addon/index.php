<?php
/**
 * Index file
 *
 * @package Ultimate Addons for Beaver Builder
 * @since Ultimate Addons for Beaver Builder
 */

/* Silence is golden, and we agree. */
