<?php
/**
 *  UABBWooAddToCartModule front-end file
 *
 *  @package UABBWooAddToCartModule
 */

?>

<div class="uabb-woo-add-to-cart">
	<?php
		$module->render_cart_button();
	?>
</div>
