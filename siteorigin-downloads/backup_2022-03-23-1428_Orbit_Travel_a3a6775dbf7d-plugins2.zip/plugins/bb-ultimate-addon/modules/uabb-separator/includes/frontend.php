<?php
/**
 *  UABB Separator Module front-end file
 *
 *  @package UABB Separator Module
 */

?>
<?php /* Separator Markup */ ?>
<div class="uabb-module-content uabb-separator-parent">
	<div class="uabb-separator"></div>
</div>
