(function($){

	FLBuilder.registerModuleHelper('uabb-heading', {

		rules: {
			heading: {
				required: true
			}
		},
		
		init: function()
		{
			var form = $('.fl-builder-settings');
		},
	});

})(jQuery);